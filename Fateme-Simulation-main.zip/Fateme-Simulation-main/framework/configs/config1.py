# configs/config1.py

config = {
    "input_file": "../macros/decay.mac",
    "output_directory": "../simulations/sim_output1/"
}
