import numpy as np
import pandas as pd
import uproot
import glob
import os

def process_to_sinogram(data, num_bins, bin_size, debug=True):
    print("Processing data to create sinogram...")
    sinogram = np.zeros((num_bins, num_bins))
    
    grouped_data = data.groupby('unique_event')
    total_events = len(grouped_data)
    valid_events = 0
    
    for event, hits in grouped_data:
        if len(hits) != 2:
            if debug:
                print(f"Event {event} skipped: contains {len(hits)} hits")
            continue
        
        hit1, hit2 = hits.iloc[0], hits.iloc[1]
        
        x1, y1, z1 = hit1['fX'], hit1['fY'], hit1['fZ']
        x2, y2, z2 = hit2['fX'], hit2['fY'], hit2['fZ']
        
        angle = np.arctan2(y2 - y1, x2 - x1)
        distance = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        
        bin_angle = int((angle + np.pi) / (2 * np.pi) * num_bins)
        bin_distance = int(distance / bin_size)
        
        if 0 <= bin_angle < num_bins and 0 <= bin_distance < num_bins:
            sinogram[bin_distance, bin_angle] += 1
            valid_events += 1
        
        if debug:
            print(f"Event {event}: angle={angle:.2f}, distance={distance:.2f}, bin_angle={bin_angle}, bin_distance={bin_distance}")
    
    print(f"Total events processed: {total_events}")
    print(f"Valid LORs added to sinogram: {valid_events}")
    print("Sinogram creation complete.")
    return sinogram

def save_as_interfile(sinogram, header_filename, data_filename):
    print(f"Saving sinogram to Interfile format: {header_filename}, {data_filename}...")
    num_bins = sinogram.shape[0]
    
    with open(header_filename, 'w') as header_file:
        header_file.write("!INTERFILE :=\n")
        header_file.write("name of data file := {}\n".format(data_filename))
        header_file.write("number of dimensions := 2\n")
        header_file.write("matrix size [1] := {}\n".format(num_bins))
        header_file.write("matrix size [2] := {}\n".format(num_bins))
        header_file.write("scaling factor (mm/pixel) [1] := 1.0\n")
        header_file.write("scaling factor (mm/pixel) [2] := 1.0\n")
        header_file.write("number format := float\n")
        header_file.write("number of bytes per pixel := 4\n")
        header_file.write("!\n")
    
    sinogram.astype('float32').tofile(data_filename)
    print("Interfile save complete.")
    print(f"Sinogram shape: {sinogram.shape}")
    print(f"Total counts in sinogram: {sinogram.sum()}")

def extract_run_and_thread_numbers(filename):
    # Extract run number (i) and thread number (j) from the filename pattern 'outputi_tj.root'
    base_name = os.path.basename(filename)
    parts = base_name.split('_')
    run_number = parts[0][6:]  # after 'output'
    thread_number = parts[1][1:-5]  # after 't' and before '.root'
    return int(run_number), int(thread_number)

num_bins = 128
bin_size = 2.0
debug = True  # Set to True to enable detailed output for each step
file_limit = 5  # Number of files to process, set to None to process all files

all_data = []
print("Loading and aggregating data from ROOT files...")
files = glob.glob('../build/output*_t*.root')
if file_limit is not None:
    files = files[:file_limit]

for filename in files:
    print(f"Processing file: {filename}")
    run_number, thread_number = extract_run_and_thread_numbers(filename)
    with uproot.open(filename) as file:
        tree = file["Hits"]
        df = tree.arrays(library="pd")
        df['run_number'] = run_number
        df['thread_number'] = thread_number
        df['unique_event'] = df['run_number'].astype(str) + '_' + df['thread_number'].astype(str) + '_' + df['fEvent'].astype(str)
        all_data.append(df)

print("All files loaded. Concatenating data...")
aggregated_data = pd.concat(all_data)
print(f"Total hits loaded: {len(aggregated_data)}")

print("Creating sinogram...")
sinogram = process_to_sinogram(aggregated_data, num_bins, bin_size, debug)

header_filename = 'sinogram.hs'
data_filename = 'sinogram.s'
save_as_interfile(sinogram, header_filename, data_filename)

print("Process complete. Sinogram files are ready for use with STIR.")

