import numpy as np

# Assuming num_bins and sinogram are already defined
num_bins = 128
sinogram = np.ones((num_bins, num_bins), dtype='float32')

# For demonstration, let's modify some values in the sinogram
sinogram[0, 0] = 0.5
sinogram[10, 10] = 2.0
sinogram[50, 50] = -1.0

# Save to file
sinogram.tofile('sinogram.s')

# Read the binary data back
loaded_sinogram = np.fromfile('sinogram.s', dtype='float32').reshape((num_bins, num_bins))

# Find and print values that are different from 1
different_values = loaded_sinogram != 1.0
different_indices = np.argwhere(different_values)

print("Values different from 1:")
for index in different_indices:
    value = loaded_sinogram[tuple(index)]
    print(f"Index: {tuple(index)}, Value: {value}")
