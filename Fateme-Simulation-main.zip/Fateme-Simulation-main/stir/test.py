import uproot
import numpy as np
import os

def convert_root_to_stir(root_files, output_prefix):
    for root_file in root_files:
        with uproot.open('../build/'+root_file) as file:
            tree = file["Hits"]
            
            # Extract the data from the tree
            fX = tree["fX"].array()
            fY = tree["fY"].array()
            fZ = tree["fZ"].array()
            fEvent = tree["fEvent"].array()
            fTime = tree["fTime"].array()
            
            # Combine the data into a single NumPy array
            data = np.column_stack((fEvent, fTime, fX, fY, fZ))
            
            # Define the output filenames
            base_filename = os.path.splitext(os.path.basename(root_file))[0]
            header_filename = f"{output_prefix}_{base_filename}.hs"
            data_filename = f"{output_prefix}_{base_filename}.s"
            
            # Write the header file
            with open(header_filename, 'w') as header_file:
                header_file.write(f"!INTERFILE  :=\n")
                header_file.write(f"!name of data file := {data_filename}\n")
                header_file.write(f"!total number of events := {len(data)}\n")
                header_file.write(f"!number format := float\n")
                header_file.write(f"!number of dimensions := 3\n")
                header_file.write(f"!matrix size [1] := {len(data)}\n")
                header_file.write(f"!matrix size [2] := 5\n")  # 5 columns: event, time, x, y, z
                header_file.write(f"!matrix size [3] := 1\n")
                header_file.write(f"!END OF INTERFILE :=\n")
            
            # Write the data file
            data.astype(np.float32).tofile(data_filename)

if __name__ == "__main__":
    # List your ROOT files here
    root_files = ["output1_t1.root", "output1_t2.root", "output2_t1.root"]
    output_prefix = "stir_output"

    convert_root_to_stir(root_files, output_prefix)

